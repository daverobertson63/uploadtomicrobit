package dhr.uploadtomicrobit;

import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

public class Alert extends JPanel {

	/**
	 * Create the panel.
	 */
	public Alert() {
		setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));

	}

}
